export const testData = {
  validClaim: {
    claimNumber: 'REPLACE_WITH_REAL_TEST_DATA'
  },
  invalidClaim: {
    claimNumber: 'REPLACE_WITH_INVALID_TEST_DATA'
  }
};
