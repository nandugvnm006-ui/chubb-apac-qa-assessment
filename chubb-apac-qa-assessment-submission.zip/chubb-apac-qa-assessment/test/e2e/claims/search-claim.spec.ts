import { test, expect } from '@playwright/test';
import { testData } from '../fixtures/test-data';

test.describe('Claim search', () => {
  test('@smoke @regression user can search for an existing claim', async ({ page }) => {
    // TODO: Replace navigation and selectors with the supplied application's real UI.
    await page.goto('/');

    await page.getByRole('link', { name: /claims/i }).click();
    await page.getByRole('textbox', { name: /claim number/i })
      .fill(testData.validClaim.claimNumber);
    await page.getByRole('button', { name: /search/i }).click();

    await expect(page.getByText(testData.validClaim.claimNumber)).toBeVisible();
  });
});
