import { test, expect } from '@playwright/test';

test.describe('Claim status', () => {
  test('@regression claim status is displayed correctly', async ({ page }) => {
    // TODO: Replace with an actual claim workflow from the supplied application.
    await page.goto('/');

    await expect(page.getByText(/status/i)).toBeVisible();
  });
});
