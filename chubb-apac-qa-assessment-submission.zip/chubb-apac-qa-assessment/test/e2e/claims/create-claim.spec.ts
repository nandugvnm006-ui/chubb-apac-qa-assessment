import { test, expect } from '@playwright/test';
import { testData } from '../fixtures/test-data';

test.describe('Claim creation', () => {
  test('@smoke @regression user can create a valid claim', async ({ page }) => {
    // TODO: Replace navigation and selectors with elements from the supplied application.
    await page.goto('/');

    await page.getByRole('link', { name: /claims/i }).click();
    await page.getByRole('button', { name: /create claim/i }).click();

    await page.getByLabel(/claim number/i).fill(testData.validClaim.claimNumber);
    await page.getByRole('button', { name: /submit/i }).click();

    await expect(page.getByText(/success/i)).toBeVisible();
  });
});
