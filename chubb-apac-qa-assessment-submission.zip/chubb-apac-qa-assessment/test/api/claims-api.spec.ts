import { test, expect } from '@playwright/test';

test.describe('Claims API', () => {
  test('@smoke critical claim API returns a successful response', async ({ request }) => {
    // TODO:
    // Replace /api/claims and the payload with the actual API contract
    // discovered in the supplied Spring Boot source.
    const response = await request.post('/api/claims', {
      data: {
        claimNumber: 'REPLACE_WITH_REAL_TEST_DATA'
      }
    });

    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body).toBeDefined();
  });
});
