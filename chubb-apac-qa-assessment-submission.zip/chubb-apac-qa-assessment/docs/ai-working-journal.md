# AI Working Journal

The assessment requires a record of AI collaboration. Keep this file factual and update it while working.

## Entry 1 - Architecture analysis

**Task:** Understand application architecture.

**AI assistance:** Used AI to help organise the initial risk-analysis structure.

**Decision:** Accepted the risk-based structure.

**Human verification:** Application source must be reviewed before finalising risks.

---

## Entry 2 - Test architecture

**Task:** Design maintainable automation.

**AI suggestion:** Use shared fixtures, reusable helpers and independent specifications.

**Decision:** Accepted.

**Reason:** Reduces duplication and supports maintainability.

---

## Entry 3 - Selector/API review

**AI suggestion:** Generate selectors/endpoints from assumptions.

**Decision:** Challenged/overridden.

**Reason:** Selectors and API contracts must come from the actual supplied application, not assumptions.

---

## Entry 4 - Failing test investigation

**AI suggestion:** Investigate whether a failure is a product defect before changing the assertion.

**Decision:** Accepted.

**Reason:** Tests should expose genuine defects rather than be changed simply to turn red into green.

---

## Entry 5 - Final review

Before submission, document:
- what AI generated
- what was manually changed
- what was rejected
- why each important test exists
- which defects were independently verified
