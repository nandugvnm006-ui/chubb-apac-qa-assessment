# Bugs Found

Only record defects that were actually reproduced through code review or test execution.

## BUG-001

**Title:** TODO

**Severity:** TODO

**Priority:** TODO

**Area:** Frontend / Backend / API / Kafka / WebSocket

**Preconditions:** TODO

**Steps to reproduce:**
1. TODO
2. TODO
3. TODO

**Expected:** TODO

**Actual:** TODO

**Evidence:** TODO

**Automated test:** TODO

**Status:** TODO

---

## Important
Do not invent bugs to make the submission look stronger. A genuine failing test that exposes a real defect is valuable; a fabricated defect is not.
