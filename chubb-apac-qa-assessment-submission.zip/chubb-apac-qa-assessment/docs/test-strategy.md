# Test Strategy

## 1. Scope

This strategy follows a risk-based approach. The supplied assessment asks for a brief assessment before/alongside automation and expects coverage of component, unit and integration behaviour.

## 2. Highest-risk areas to validate

After inspecting the actual application, record evidence for:

1. Claim creation and validation
2. Claim status transitions
3. Frontend-to-backend integration
4. Backend business rules
5. Messaging/Kafka boundaries
6. WebSocket real-time updates
7. Error handling and failure recovery

## 3. Selected coverage

### Component
Test user-visible Angular behaviour using Testing Library.

### Unit
Test business logic/services in isolation.

### Integration
Test important API and messaging boundaries.

### E2E
Use Playwright for the highest-value user journeys.

## 4. Deliberately excluded

Because the assessment is time-boxed, do not attempt exhaustive coverage. Potential exclusions:

- exhaustive browser/device combinations
- cosmetic-only checks
- every Kafka message variation
- exhaustive backend branches
- load testing unless time permits

## 5. Actual findings

Replace this section after source-code review and execution.

- Finding 1: TODO
- Finding 2: TODO

## 6. Prioritisation rationale

Prioritise by:

Business impact -> probability -> complexity -> integration risk -> user visibility
